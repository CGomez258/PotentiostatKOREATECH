#include <SPI.h>
#include <math.h>

HardwareSerial Serial1(PA10, PA9);
SPIClass SPI_1(PA7, PA6, PA5);

SPISettings spiDAC(1000000, MSBFIRST, SPI_MODE1);
SPISettings spiADC(500000,  MSBFIRST, SPI_MODE1);

#define DAC_CS   PB0
#define ADC_CS   PB6

/* ===== DAC: AD5683R ===== */
const uint8_t AD5683_CMD_WR_DAC  = 0x3;
const uint8_t AD5683_CMD_WR_CTRL = 0x4;

const float DAC_FS = 5.0f;   // 0..5V (internal 2.5V ref, gain=2)
const float VSET_LOW  = 0.0f;
const float VSET_HIGH = 1.0f;

static void ad5683_write(uint8_t cmd, uint32_t data20) {
  uint32_t frame = ((uint32_t)cmd << 20) | (data20 & 0xFFFFF);
  uint8_t b1 = (frame >> 16) & 0xFF;
  uint8_t b2 = (frame >> 8)  & 0xFF;
  uint8_t b3 =  frame        & 0xFF;

  SPI_1.beginTransaction(spiDAC);
  digitalWrite(DAC_CS, LOW);
  SPI_1.transfer(b1); SPI_1.transfer(b2); SPI_1.transfer(b3);
  digitalWrite(DAC_CS, HIGH);
  SPI_1.endTransaction();
}

static void ad5683_init() {
  uint32_t ctrl = (1u << 15); // gain=2x
  ad5683_write(AD5683_CMD_WR_CTRL, ctrl);
}

static inline uint16_t voltageToCode(float v) {
  if (v < 0.0f) v = 0.0f;
  if (v > 1.0f) v = 1.0f;     // clamp sweep to 0..1V
  return (uint16_t)((v / DAC_FS) * 65535.0f + 0.5f);
}

static inline void ad5683_setVoltage(float v) {
  uint32_t data20 = ((uint32_t)voltageToCode(v)) << 4;
  ad5683_write(AD5683_CMD_WR_DAC, data20);
}

/* ===== ADC: ADS1118 ===== */
#define ADS_SS_START         0x8000

#define ADS_MUX_AIN0_AIN1    0x0000  // (AIN0 - AIN1) = (Vout - Vmid)
#define ADS_MUX_AIN2_AIN3    0x3000  // (AIN2 - AIN3) = (RE - WE)

#define ADS_PGA_2_048V       0x0400
#define ADS_PGA_1_024V       0x0600

#define ADS_MODE_SINGLE      0x0100
#define ADS_DR_128SPS        0x0080
#define ADS_PULLUP_EN        0x0008
#define ADS_NOP_01           0x0002
#define ADS_RESERVED_1       0x0001

static inline uint16_t ads_cfg(uint16_t mux, uint16_t pga) {
  return (ADS_SS_START | mux | pga | ADS_MODE_SINGLE | ADS_DR_128SPS |
          ADS_PULLUP_EN | ADS_NOP_01 | ADS_RESERVED_1);
}

static void ads1118_xfer32(uint16_t cfg, int16_t &conv, uint16_t &cfg_rb) {
  uint8_t tx[4] = {(uint8_t)(cfg >> 8), (uint8_t)(cfg & 0xFF),
                   (uint8_t)(cfg >> 8), (uint8_t)(cfg & 0xFF)};
  uint8_t rx[4];

  SPI_1.beginTransaction(spiADC);
  digitalWrite(ADC_CS, LOW);
  for (int i = 0; i < 4; i++) rx[i] = SPI_1.transfer(tx[i]);
  digitalWrite(ADC_CS, HIGH);
  SPI_1.endTransaction();

  conv   = (int16_t)(((uint16_t)rx[0] << 8) | rx[1]);
  cfg_rb = (uint16_t)(((uint16_t)rx[2] << 8) | rx[3]);
}

static inline float ads_code_to_volts(int16_t code, float fsVolts) {
  return (float)code * (fsVolts / 32768.0f);
}

static int16_t ads_read_once(uint16_t cfgStart) {
  int16_t conv; uint16_t rb;
  ads1118_xfer32(cfgStart, conv, rb);
  delay(10);
  uint16_t cfgRead = (cfgStart & ~ADS_SS_START);
  ads1118_xfer32(cfgRead, conv, rb);
  return conv;
}

static float ads_read_diff_volts(uint16_t muxSel, uint16_t pgaSel, float fsVolts) {
  uint16_t cfg = ads_cfg(muxSel, pgaSel);
  (void)ads_read_once(cfg); // throw away first after mux change
  delay(2);

  float sum = 0.0f;
  const int N = 4;
  for (int i = 0; i < N; i++) {
    sum += ads_code_to_volts(ads_read_once(cfg), fsVolts);
    delay(2);
  }
  return sum / N;
}

/* ===== Measurements ===== */
const float R_TIA = 10000.0f; // ohms (set your real TIA resistor)

// E = WE - RE = -(RE - WE)
static float measure_E_WE_minus_RE() {
  float re_minus_we = ads_read_diff_volts(ADS_MUX_AIN2_AIN3, ADS_PGA_2_048V, 2.048f);
  return -re_minus_we;
}

// I = -(Vout - Vmid)/R
static float measure_current_uA() {
  float Vout_minus_Vmid = ads_read_diff_volts(ADS_MUX_AIN0_AIN1, ADS_PGA_1_024V, 1.024f);
  return -(Vout_minus_Vmid / R_TIA) * 1e6f;
}

/* ===== Sweep settings ===== */
const float V_STEP = 0.01f;        // 10 mV step
const float SWEEP_TIME_S = 180.0f;  // total time up+down

static void print_line(float Vset, float E, float IuA) {
  // Columns: Vset  E(WE-RE)  IuA
  Serial1.print(E, 4);    Serial1.print(" ");
  Serial1.print(IuA, 3);  Serial1.print(" ");
  Serial1.print(Vset, 4); Serial1.println(" ");
}

void setup() {
  Serial1.begin(9600);

  pinMode(DAC_CS, OUTPUT);
  pinMode(ADC_CS, OUTPUT);
  digitalWrite(DAC_CS, HIGH);
  digitalWrite(ADC_CS, HIGH);

  SPI_1.begin();
  ad5683_init();

  ad5683_setVoltage(VSET_LOW);
  delay(200);
}

void loop() {
  float span = VSET_HIGH - VSET_LOW;
  int steps = (int)(span / V_STEP + 0.5f);

  float legTimeS = SWEEP_TIME_S * 0.5f;
  float scanRate = span / legTimeS; // V/s per leg
  uint32_t step_ms = (uint32_t)((V_STEP / scanRate) * 1000.0f + 0.5f);
  if (step_ms < 5) step_ms = 5;
  
  // float Vset = 0.0f;
  // ad5683_setVoltage(Vset);
  // float E   = measure_E_WE_minus_RE();
  // float IuA = measure_current_uA();
  // print_line(Vset, E, IuA);
  // delay(10000);
//open loop code
  for (int i = 0; i <= steps; i++) {
    float Vset = VSET_LOW + i * V_STEP;
    ad5683_setVoltage(Vset);
    delay(step_ms);

    float E   = measure_E_WE_minus_RE();
    float IuA = measure_current_uA();
    print_line(Vset, E, IuA);
  }

  for (int i = 1; i <= steps; i++) {
    float Vset = VSET_HIGH - i * V_STEP;
    ad5683_setVoltage(Vset);
    delay(step_ms);

    float E   = measure_E_WE_minus_RE();
    float IuA = measure_current_uA();
    print_line(Vset, E, IuA);
  }

  while (1) {
    ad5683_setVoltage(VSET_LOW);
    delay(1000);
  }
}

